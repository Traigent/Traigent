# Bazak Optimization — Results Validation & Evidence Report

**Date**: 2026-03-03
**Experiment ID**: `55a4bf49fd4730a3bb8e9bb4722f8dea`
**Run ID**: `06ab71ea-706d-4554-91df-40d6e0e552f6`
**Algorithm**: GridSearchOptimizer (exhaustive, 4 models × 3 examples)

---

## 1. Executive Summary

**All 130 automated checks pass.** The FE CSV export is fully consistent with:
- SDK `results.json`
- SDK optimization logs (`trials_v2.jsonl`)
- SDK per-trial JSON files (`trial_*_v2.json`)

Two FE-only columns — **Content Novelty** (0.5000) and **Content Uniqueness** (0.8336) — are not stored in SDK trial-level `results.json` metrics. They come from per-example content scores propagated through backend analytics.

The **"Cost"** column in the FE CSV shows the **per-example cost value** surfaced by FE metric extraction, while SDK `results.json` stores trial-level total cost. For this run, FE "Cost" equals SDK `total_cost / 3`.

---

## 2. Data Sources Compared

| Source | Location | Description |
|--------|----------|-------------|
| **FE CSV** | `configuration_runs_06ab71ea-...csv` | Frontend "Export Configuration Runs" |
| **SDK results.json** | `examples/bazak/results.json` | SDK GridSearchOptimizer output |
| **JSONL logs** | `.traigent/.../trials_v2.jsonl` | SDK per-trial optimization logs |
| **Trial JSON files** | `.traigent/.../trial_trial_*_v2.json` | SDK individual trial files |

### Trial IDs (all 4 sources agree):

| Trial ID | Model |
|----------|-------|
| `trial_5822ccd7098e` | gemini-3-flash-preview |
| `trial_94093768acc4` | gemini-2.5-flash |
| `trial_4ce3058b9394` | gpt-5-nano-2025-08-07 |
| `trial_444582cb961a` | gpt-5-mini-2025-08-07 |

---

## 3. Per-Trial Metric Validation

### 3.1 trial_94093768acc4 — gemini-2.5-flash (BEST PERFORMER)

| Metric | FE CSV | SDK results.json | JSONL | Trial File | Match |
|--------|--------|------------------|-------|------------|-------|
| Status | completed | completed | completed | completed | OK |
| Model | gemini-2.5-flash | gemini-2.5-flash | gemini-2.5-flash | gemini-2.5-flash | OK |
| tool_accuracy | 0.6667 | 0.6667 | 0.6667 | 0.6667 | OK |
| param_accuracy | 1.0000 | 1.0000 | 1.0000 | 1.0000 | OK |
| text_accuracy | 1.0000 | 1.0000 | 1.0000 | 1.0000 | OK |
| Score | 83.33% | 0.8333 | 0.8333 | 0.8333 | OK |
| Accuracy | 83.33% | 0.8333 | 0.8333 | 0.8333 | OK |
| Latency | 11286.0000 | 11286.0 | 11286.0 | 11286.0 | OK |
| Cost (FE) | $0.008225 | — | — | — | see §4 |
| Cost (SDK) | — | 0.0246747 | 0.0246747 | 0.0246747 | OK |
| success_rate | 1.0000 | 1.0 | 1.0 | 1.0 | OK |

### 3.2 trial_5822ccd7098e — gemini-3-flash-preview

| Metric | FE CSV | SDK results.json | JSONL | Trial File | Match |
|--------|--------|------------------|-------|------------|-------|
| tool_accuracy | 0.6667 | 0.6667 | 0.6667 | 0.6667 | OK |
| param_accuracy | 0.0000 | 0.0 | 0.0 | 0.0 | OK |
| text_accuracy | 1.0000 | 1.0 | 1.0 | 1.0 | OK |
| Score | 66.67% | 0.6667 | 0.6667 | 0.6667 | OK |
| Accuracy | 66.67% | 0.6667 | 0.6667 | 0.6667 | OK |
| Latency | 16322.6667 | 16322.6667 | 16322.6667 | 16322.6667 | OK |
| Cost (FE) | $0.0179 | — | — | — | see §4 |
| Cost (SDK) | — | 0.053733 | 0.053733 | 0.053733 | OK |
| success_rate | 1.0000 | 1.0 | 1.0 | 1.0 | OK |

### 3.3 trial_444582cb961a — gpt-5-mini-2025-08-07

| Metric | FE CSV | SDK results.json | JSONL | Trial File | Match |
|--------|--------|------------------|-------|------------|-------|
| tool_accuracy | 0.3333 | 0.3333 | 0.3333 | 0.3333 | OK |
| param_accuracy | 0.0000 | 0.0 | 0.0 | 0.0 | OK |
| text_accuracy | 1.0000 | 1.0 | 1.0 | 1.0 | OK |
| Score | 50.00% | 0.5 | 0.5 | 0.5 | OK |
| Accuracy | 50.00% | 0.5 | 0.5 | 0.5 | OK |
| Latency | 36679.6667 | 36679.6667 | 36679.6667 | 36679.6667 | OK |
| Cost (FE) | $0.006551 | — | — | — | see §4 |
| Cost (SDK) | — | 0.0196525 | 0.0196525 | 0.0196525 | OK |
| success_rate | 1.0000 | 1.0 | 1.0 | 1.0 | OK |

### 3.4 trial_4ce3058b9394 — gpt-5-nano-2025-08-07

| Metric | FE CSV | SDK results.json | JSONL | Trial File | Match |
|--------|--------|------------------|-------|------------|-------|
| tool_accuracy | 0.3333 | 0.3333 | 0.3333 | 0.3333 | OK |
| param_accuracy | 0.0000 | 0.0 | 0.0 | 0.0 | OK |
| text_accuracy | 1.0000 | 1.0 | 1.0 | 1.0 | OK |
| Score | 33.33% | 0.3333 | 0.3333 | 0.3333 | OK |
| Accuracy | 33.33% | 0.3333 | 0.3333 | 0.3333 | OK |
| Latency | 32653.0000 | 32653.0 | 32653.0 | 32653.0 | OK |
| Cost (FE) | $0.001586 | — | — | — | see §4 |
| Cost (SDK) | — | 0.004757 | 0.004757 | 0.004757 | OK |
| success_rate | 1.0000 | 1.0 | 1.0 | 1.0 | OK |

---

## 4. Cost Column — Detailed Explanation

The FE "Cost" column shows a **per-example average cost**, while the SDK stores the **total trial cost** (sum across all 3 examples). These are consistent.

### How Cost Flows Through the System

**Step 1 — Bazak API returns total cost per execution batch:**

The Bazak `/traigent/v1/execute` endpoint returns operational metrics including total cost for the entire batch of 3 examples.

**Step 2 — SDK computes per-example cost with fallback logic:**

```python
# traigent/evaluators/hybrid_api.py, lines 692-694
fallback_cost = self._coerce_metric(response.get_total_cost()) / max(
    len(inputs), 1
)

# lines 716-718
cost = self._coerce_metric(output_item.get("cost_usd"), fallback_cost)
```

`total_cost / len(inputs)` is used only when per-item `cost_usd` is missing.

**Step 3 — SDK aggregates total cost at trial level:**

```python
# traigent/evaluators/hybrid_api.py, lines 916-919
aggregated: dict[str, float] = {
    "cost": total_cost,        # Sum of all example costs = original batch cost
    "total_cost": total_cost,  # Same value
    ...
}
```

**Step 4 — SDK submits per-example measures to Backend:**

```python
# traigent/core/metadata_helpers.py, lines 352-387 (_build_single_measure_full)
# Per-example metrics are copied from example_result.metrics into measures.
# Cost shown in FE for this run resolves to per-example values.
```

**Step 5 — Frontend metric extraction checks summary stats first:**

```javascript
// TraigentFrontend/src/utils/experimentUtils.js, lines 121-154
export const getMetricValue = (run, metricName) => {
  if (run.summary_stats?.metrics) {
    const metric = run.summary_stats.metrics[metricName];
    if (metric !== undefined) {
      if (typeof metric === 'object' && metric !== null && 'mean' in metric) {
        return metric.mean;
      }
      return metric;
    }
  }
  // Fallback: mean over run.measures[]
  if (run.measures && Array.isArray(run.measures) && run.measures.length > 0) {
    const values = run.measures
      .map((measure) => measure?.metrics?.[metricName] ?? measure?.[metricName])
      .filter((val) => val !== undefined && val !== null && !isNaN(val));
    if (values.length > 0) {
      const sum = values.reduce((acc, val) => acc + Number(val), 0);
      return sum / values.length;
    }
  }
};
```

In this run, summary stats already contain per-example means for `cost`/`total_cost`:

```python
# traigent/evaluators/hybrid_api.py, lines 419-421 (_build_summary_stats)
metric_values.setdefault("cost", cost_values)
metric_values.setdefault("total_cost", cost_values)
```

**Step 6 — FE cost accessor tries `total_cost` first, then `cost`:**

```typescript
// TraigentFrontend/src/hooks/useColumnManager.tsx, lines 526-537
if (measureKey === 'cost') {
  const totalCost = getMetricValue(run, 'total_cost');
  if (totalCost !== undefined) return totalCost;
  const cost = getMetricValue(run, 'cost');
  if (cost !== undefined) return cost;
  ...
}
```

### Verification Math

| Trial | SDK Total Cost | ÷ 3 Examples | FE CSV "Cost" | Match |
|-------|---------------|-------------|---------------|-------|
| gemini-3-flash-preview | $0.053733 | $0.017911 | $0.0179 | Yes (rounded) |
| gemini-2.5-flash | $0.024675 | $0.008225 | $0.008225 | Yes |
| gpt-5-nano | $0.004757 | $0.001586 | $0.001586 | Yes |
| gpt-5-mini | $0.019653 | $0.006551 | $0.006551 | Yes |

**Note**: FE "Cost" and "Total Cost" columns display the **same per-example value** because the FE's default "cost" column resolves `total_cost` first, and that value is a per-example mean in this data path. This is a display quirk, not a metric inconsistency.

---

## 5. Score & Accuracy — How They're Derived

### SDK Computation

**Step 1 — Evaluate endpoint returns per-example metrics:**

Each example gets quality metrics from Bazak `/traigent/v1/evaluate`, and may include explicit `accuracy`.

**Step 2 — SDK keeps explicit per-example `accuracy` when present, otherwise derives it:**

```python
# traigent/evaluators/hybrid_api.py, lines 375-378 (_normalize_example_metrics)
if "accuracy" not in normalized:
    derived_accuracy = cls._derive_accuracy_from_metrics(normalized)
    if derived_accuracy is not None:
        normalized["accuracy"] = derived_accuracy
```

```python
# lines 334-360 (_derive_accuracy_from_metrics) fallback order:
# 1) accuracy
# 2) overall_accuracy
# 3) mean(*_accuracy)
```

**Step 3 — SDK aggregates per-example metrics as means:**

```python
# traigent/evaluators/hybrid_api.py, lines 935-939
for metric_name, total in metric_sums.items():
    count = metric_counts[metric_name]
    if count > 0:
        aggregated[metric_name] = total / count
```

**Step 4 — Score defaults to accuracy when not provided explicitly:**

```python
# traigent/evaluators/hybrid_api.py, lines 951-952
if "score" not in aggregated and "accuracy" in aggregated:
    aggregated["score"] = aggregated["accuracy"]
```

### Verification: gemini-2.5-flash (trial_94093768acc4)

Per-example `accuracy` values in the trial file are:
- Example 1: accuracy = 1.0 (from trial JSON `example_results[0].accuracy`)
- Example 2: accuracy = 1.0
- Example 3: accuracy = 0.5

Trial accuracy is the mean of those per-example accuracies:

`(1.0 + 1.0 + 0.5) / 3 = 0.8333` → matches SDK and FE.

So for this run, `accuracy` comes from explicit per-example values provided by evaluate output; the SDK fallback `mean(*_accuracy)` path is available but was not needed for these rows.

### FE Formatting

```typescript
// TraigentFrontend/src/hooks/useColumnManager.tsx, lines 300-307
} else if (
  key === 'score' || key === 'accuracy' || key === 'precision' ||
  key === 'recall' || key === 'f1'
) {
  return `${(numValue * 100).toFixed(2)}%`;
}
```

0.8333 × 100 = 83.33% — matches FE CSV.

---

## 6. Latency / Response Time

### SDK Computation

```python
# traigent/evaluators/hybrid_api.py, lines 942-944
latencies = [r.latency_ms for r in results if r.latency_ms > 0]
if latencies:
    aggregated["latency"] = sum(latencies) / len(latencies)
```

Latency is the **mean of per-example latencies** in milliseconds.

### Verification: gemini-2.5-flash (trial_94093768acc4)

Per-example latencies from trial file:
- Example 1: latency_ms = 12181.0
- Example 2: latency_ms = 10738.0
- Example 3: latency_ms = 10939.0

Mean = (12181 + 10738 + 10939) / 3 = **11286.0** — matches FE CSV "11286.00ms".

### FE Formatting

```typescript
// TraigentFrontend/src/hooks/useColumnManager.tsx, lines 296-299
} else if (key.includes('time_ms')) {
  return `${numValue.toFixed(2)}ms`;
}
```

---

## 7. Content Novelty & Content Uniqueness (FE-Only)

These two columns appear in the FE CSV but are **NOT** in SDK trial-level `results.json` metrics.

| Trial | Content Novelty | Content Uniqueness |
|-------|----------------|--------------------|
| All 4 trials | 0.5000 | 0.8336 |

### Origin: SDK content scoring + backend aggregation

```python
# Traigent SDK computes dataset content scores once per run:
# traigent/core/orchestrator.py, lines 1537-1539 and 2229-2274
# uniqueness_scores = scorer.compute_uniqueness_scores(example_inputs)
# novelty_scores = scorer.compute_novelty_scores(example_inputs)
```

```python
# Scores are attached to per-example measures before backend submission:
# traigent/core/metadata_helpers.py, lines 338-349

# Backend then reads/averages them (defaulting to 0.5 only if absent):
# TraigentBackend/src/services/analytics/example_scoring_service.py, lines 164-165, 297-302
content_uniqueness = self._safe_mean(
    [tr["content_uniqueness"] for tr in trial_results], default=0.5
)
content_novelty = self._safe_mean(
    [tr["content_novelty"] for tr in trial_results], default=0.5
)
```

For this run:
- `ContentScorer` was active in the SDK orchestration path.
- Mean novelty computed from the 3 inputs is `0.5000`.
- Mean uniqueness computed from the 3 inputs is `0.8336` (rounded from `0.833593...`).

So `0.5000` and `0.8336` are not arbitrary FE values; they come from SDK content-score inputs propagated through backend analytics and averaged per example across trials.

---

## 8. Automated Validation Results

The script `examples/bazak/validate_results.py` performs **130 checks** across all 4 data sources:

```
======================================================================
  TOTAL CHECKS: 130
  PASSED:       130
  FAILED:       0
======================================================================
```

### Check Categories

- Trial ID set consistency across FE / SDK results / JSONL / trial files
- Per-trial status, model, and full config consistency
- Cross-source metric consistency for `tool_accuracy`, `param_accuracy`, `text_accuracy`, `accuracy`, `score`, `latency`, `response_time_ms`, `cost`, `total_cost`, `success_rate`, `examples_attempted`
- FE formatted metric consistency (percent parsing, ms parsing, dollar parsing)
- Cost semantics check: FE per-example display vs SDK total-trial cost
- FE-only field presence checks for Content Novelty / Content Uniqueness
- JSONL-vs-trial-file deep check with **strict key-set validation** (no missing-key false passes)

---

## 9. Full Data Flow Architecture

```
Bazak API (ai.bazak.ai)
    │
    ├── /execute → returns outputs + cost_usd + latency_ms per example
    ├── /evaluate → returns tool_accuracy, param_accuracy, text_accuracy per example
    │
    ▼
Traigent SDK (HybridAPIEvaluator)
    │
    ├── Per-example: HybridExampleResult(cost_usd, latency_ms, metrics{tool/param/text_accuracy/...})
    ├── Aggregation: _compute_aggregated_metrics() → mean of per-example metrics
    │   ├── cost = total_cost (sum of per-example costs)
    │   ├── latency = mean(per-example latency_ms)
    │   ├── tool_accuracy = mean(per-example tool_accuracy)
    │   ├── accuracy = mean(per-example accuracy) when accuracy exists per item
    │   │             fallback derivation available from *_accuracy
    │   └── score = accuracy (when not explicitly set)
    │
    ├── Content scoring (once per dataset):
    │   └── ContentScorer computes uniqueness/novelty, attached to per-example measures
    │
    ├── Local logs: trials_v2.jsonl + trial_*_v2.json (trial-level aggregated metrics)
    ├── results.json (trial-level aggregated metrics)
    │
    ├── Backend submission: build_backend_metadata()
    │   ├── summary_stats: trial-level aggregated metrics
    │   └── measures: per-example [{example_id, metrics{cost, tool_accuracy, ...}}]
    │       └── cost in measures = per-example cost
    │           (per-item cost_usd when present, else total/num_examples fallback)
    │
    ▼
Traigent Backend
    │
    ├── PUT /runs/{run_id}/configurations/{config_id}/measures
    │   └── Stores measures[] and summary_stats in configuration_runs table
    │
    ├── ExampleScoringService (analytics)
    │   ├── Reads content_uniqueness/content_novelty from measures (default: 0.5 if absent)
    │   └── Computes additional statistical quality metrics
    │
    ▼
Traigent Frontend
    │
    ├── getMetricValue(run, metricName):
    │   ├── Checks summary_stats.metrics first
    │   └── Falls back to mean(measures[].metrics[metricName])
    │
    ├── Cost accessor: tries total_cost → cost → input_cost+output_cost
    │   └── Result = per-example cost for this run
    │      (summary_stats metrics are mean values)
    │
    ├── Formatting:
    │   ├── Score/Accuracy: value × 100 → "XX.XX%"
    │   ├── Cost: "$X.XXXX" (variable precision)
    │   └── Response Time: "XXXX.XXms"
    │
    └── CSV Export: BestPerformersPanel.handleExportCSV()
        └── Iterates visible columns, applies formatter, writes Blob
```

---

## 10. Code References

### SDK Files

| File | Lines | Purpose |
|------|-------|---------|
| `traigent/evaluators/hybrid_api.py` | 692-694 | Cost division: `total_cost / len(inputs)` |
| `traigent/evaluators/hybrid_api.py` | 716-718, 821-823 | Per-item cost precedence (`output_item.cost_usd` over fallback) |
| `traigent/evaluators/hybrid_api.py` | 788-790 | Same cost division in evaluate path |
| `traigent/evaluators/hybrid_api.py` | 907-956 | `_compute_aggregated_metrics()`: mean of per-example metrics |
| `traigent/evaluators/hybrid_api.py` | 334-360 | `_derive_accuracy_from_metrics()`: mean of `*_accuracy` metrics |
| `traigent/evaluators/hybrid_api.py` | 375-378 | `_normalize_example_metrics()`: derives `accuracy` only when missing |
| `traigent/evaluators/hybrid_api.py` | 951-952 | `score = accuracy` fallback |
| `traigent/evaluators/hybrid_api.py` | 419-421 | `summary_stats` uses mean per-example values for `cost`/`total_cost` |
| `traigent/core/orchestrator.py` | 1537-1539 | Computes content scores once per run |
| `traigent/core/orchestrator.py` | 2229-2274 | `_compute_content_scores()` using `ContentScorer` |
| `traigent/metrics/content_scoring.py` | 72-194 | Uniqueness/novelty scoring implementation |
| `traigent/core/metadata_helpers.py` | 245-314 | `build_backend_metadata()`: builds measures + summary_stats |
| `traigent/core/metadata_helpers.py` | 352-387 | `_build_single_measure_full()`: per-example measure with cost |
| `traigent/core/metadata_helpers.py` | 338-349 | `_add_content_scores()`: adds content_uniqueness/novelty to measures |
| `traigent/core/backend_session_manager.py` | 316-358 | `submit_trial()`: sends trial to backend |
| `traigent/cloud/trial_operations.py` | 624-630 | POST to `/sessions/{id}/results` |

### Backend Files

| File | Lines | Purpose |
|------|-------|---------|
| `src/routes/configuration_run_routes.py` | 170-205 | PUT measures endpoint |
| `src/routes/configuration_run_routes.py` | 242-273 | `_transform_measures_to_schema_format()` |
| `src/models/configuration_run.py` | 36 | `measures = db.Column(JSONType)` |
| `src/services/analytics/example_scoring_service.py` | 156-172 | Reads content scores from measures (default `0.5` only if absent) |
| `src/services/analytics/example_scoring_service.py` | 295-302 | Averages content scores per example across trials |

### Frontend Files

| File | Lines | Purpose |
|------|-------|---------|
| `src/utils/experimentUtils.js` | 121-154 | `getMetricValue()`: summary_stats first, then measures average |
| `src/hooks/useColumnManager.tsx` | 526-537 | Cost accessor with `total_cost`/`cost` priority |
| `src/hooks/useColumnManager.tsx` | 300-307 | Score/accuracy formatting: `(value * 100).toFixed(2)%` |
| `src/hooks/useColumnManager.tsx` | 270-312 | Cost formatting: `$X.XXXX` |
| `src/hooks/useColumnManager.tsx` | 296-299 | Response time formatting: `X.XXms` |
| `src/components/experiment/BestPerformersPanel.tsx` | 72-96 | CSV export via Blob API |

---

## 11. Known Observations (Not Bugs)

1. **FE "Cost" and "Total Cost" columns show the same value** — The FE default cost accessor resolves `total_cost` first, and in this data path that value is a per-example mean (from `summary_stats`). The "Total Cost" label is misleading in this context.

2. **Content Novelty is 0.5000** — In this run, SDK `ContentScorer` produced novelty values whose mean is `0.5000` for the three Bazak input IDs. Backend default `0.5` remains a fallback path if scores are missing.

3. **Content Uniqueness is 0.8336 for all trials** — This originates from SDK content scoring and is propagated in measures; backend averages it per example across trials. The same value appears per trial because FE displays aggregated per-example analytics, not per-trial model-specific uniqueness.

4. **SDK "best_config" is gemini-3-flash-preview, not gemini-2.5-flash** — The optimizer was configured with `objectives=["tool_accuracy"]`. Both gemini-3-flash-preview and gemini-2.5-flash have tool_accuracy=0.6667. The optimizer selected the first one encountered (gemini-3-flash-preview was trial #1). When factoring in param_accuracy and the overall accuracy score, gemini-2.5-flash (83.33%) outperforms gemini-3-flash-preview (66.67%).

---

## 12. Validation Script

The automated validation script is at `examples/bazak/validate_results.py`. To run:

```bash
cd Traigent
.venv/bin/python examples/bazak/validate_results.py
```

It compares all 4 data sources across 130 checks covering trial IDs, status, model/config, cross-source metric equality, strict JSONL-vs-file key/metric comparison, cost semantics, and FE-only fields.

---

*Generated on 2026-03-03 by automated validation pipeline.*
