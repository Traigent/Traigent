#!/usr/bin/env python3
"""Validate consistency across all Bazak optimization data sources.

Compares:
  1. FE CSV export (configuration_runs export from frontend)
  2. SDK results.json (saved by run_optimization.py)
  3. SDK optimization logs (trials_v2.jsonl)
  4. SDK per-trial JSON files (trial_*_v2.json)

Flags any discrepancies with FAIL; passes with OK.
"""

import csv
import json
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).parent.absolute()
PROJECT_ROOT = SCRIPT_DIR.parents[1]

# --- Data source paths ---
FE_CSV = PROJECT_ROOT / "examples" / "configuration_runs_06ab71ea-706d-4554-91df-40d6e0e552f6 (1).csv"
SDK_RESULTS = SCRIPT_DIR / "results.json"
TRIALS_JSONL = (
    PROJECT_ROOT
    / ".traigent"
    / "optimization_logs"
    / "experiments"
    / "bazak_agent"
    / "runs"
    / "20260302_201509_ebaeaa93"
    / "trials"
    / "trials_v2.jsonl"
)
TRIALS_DIR = TRIALS_JSONL.parent

ABS_TOL_DEFAULT = 1e-9
REL_TOL_DEFAULT = 1e-6

# Field-specific absolute tolerances (tight but practical for CSV rounding).
TOLERANCES = {
    "accuracy_like": 5e-4,     # FE percentages are rounded to 2 decimals.
    "latency_ms": 5e-2,        # FE response time formatting keeps 2 decimals.
    "cost_per_example": 5e-5,  # FE cost column may be rounded to 4-6 decimals.
    "cost_total": 1e-9,        # SDK/JSONL/trial-file totals should be exact.
}


def load_fe_csv() -> dict[str, dict]:
    """Load FE CSV keyed by trial ID."""
    rows = {}
    with open(FE_CSV, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            tid = row["ID"].strip()
            rows[tid] = {
                "status": row["Status"].strip(),
                "model": row["Model"].strip(),
                "total_examples": int(row["Total Examples"].strip()),
                "score_pct": row[" Score"].strip(),  # note leading space in header
                "accuracy_pct": row["Accuracy"].strip(),
                "cost_str": row["Cost"].strip(),
                "response_time_str": row["Response Time (ms)"].strip(),
                "content_novelty": float(row["Content Novelty"].strip()),
                "content_uniqueness": float(row["Content Uniqueness"].strip()),
                "param_accuracy": float(row["Param Accuracy"].strip()),
                "tool_accuracy": float(row["Tool Accuracy"].strip()),
                "latency": float(row["Latency"].strip()),
                "success_rate": float(row["Success Rate"].strip()),
                "text_accuracy": float(row["Text Accuracy"].strip()),
                "total_cost_str": row["Total Cost"].strip(),
            }
    return rows


def load_sdk_results() -> dict[str, dict]:
    """Load SDK results.json keyed by trial ID."""
    with open(SDK_RESULTS) as f:
        data = json.load(f)
    return {t["trial_id"]: t for t in data["trials"]}


def load_jsonl_trials() -> dict[str, dict]:
    """Load trials_v2.jsonl keyed by trial ID."""
    trials = {}
    with open(TRIALS_JSONL) as f:
        for line in f:
            line = line.strip()
            if line:
                d = json.loads(line)
                trials[d["trial_id"]] = d
    return trials


def load_trial_files() -> dict[str, dict]:
    """Load individual trial_*_v2.json files keyed by trial ID."""
    trials = {}
    for p in TRIALS_DIR.glob("trial_trial_*_v2.json"):
        with open(p) as f:
            d = json.load(f)
            trials[d["trial_id"]] = d
    return trials


def parse_pct(s: str) -> float:
    """Parse '66.67%' -> 0.6667."""
    return float(s.replace("%", "")) / 100.0


def parse_dollar(s: str) -> float:
    """Parse '$0.0179' -> 0.0179."""
    return float(s.replace("$", "").replace(",", ""))


def approx_eq(
    a: float,
    b: float,
    abs_tol: float = ABS_TOL_DEFAULT,
    rel_tol: float = REL_TOL_DEFAULT,
) -> bool:
    """Check approximate equality."""
    if a == b:
        return True
    diff = abs(a - b)
    if diff <= abs_tol:
        return True
    return diff / max(abs(a), abs(b), 1e-12) <= rel_tol


def all_close(
    values: dict[str, float],
    abs_tol: float,
    rel_tol: float = REL_TOL_DEFAULT,
) -> bool:
    """Check all numeric values in dict are close to each other."""
    if len(values) <= 1:
        return True
    it = iter(values.values())
    first = next(it)
    return all(approx_eq(first, v, abs_tol=abs_tol, rel_tol=rel_tol) for v in it)


def main() -> int:
    print("=" * 70)
    print("  Bazak Results Validation")
    print("=" * 70)

    fe = load_fe_csv()
    sdk = load_sdk_results()
    jsonl = load_jsonl_trials()
    files = load_trial_files()

    all_trial_ids = sorted(set(fe) | set(sdk) | set(jsonl) | set(files))
    print(f"\n  FE CSV trials:     {sorted(fe.keys())}")
    print(f"  SDK results trials:{sorted(sdk.keys())}")
    print(f"  JSONL trials:      {sorted(jsonl.keys())}")
    print(f"  File trials:       {sorted(files.keys())}")

    failures = []
    checks = 0

    def check(desc: str, condition: bool, detail: str = ""):
        nonlocal checks
        checks += 1
        if condition:
            print(f"  [OK]   {desc}")
        else:
            msg = f"  [FAIL] {desc}"
            if detail:
                msg += f" — {detail}"
            print(msg)
            failures.append(msg)

    fe_example_counts = sorted({row["total_examples"] for row in fe.values()})
    check(
        "FE total_examples consistent across rows",
        len(fe_example_counts) == 1,
        f"values={fe_example_counts}",
    )
    expected_examples = fe_example_counts[0] if len(fe_example_counts) == 1 else None

    # --- Check 1: Same trial IDs across all sources ---
    print("\n--- Check 1: Trial ID consistency ---")
    check(
        "All sources have same trial IDs",
        set(fe) == set(sdk) == set(jsonl) == set(files),
        f"FE={set(fe)}, SDK={set(sdk)}, JSONL={set(jsonl)}, Files={set(files)}",
    )

    # --- Check 2: Per-trial metric consistency ---
    print("\n--- Check 2: Per-trial metrics across sources ---")
    for tid in all_trial_ids:
        if tid not in fe or tid not in sdk or tid not in jsonl or tid not in files:
            check(f"{tid}: present in all sources", False, "missing in one or more")
            continue

        f_row = fe[tid]
        s_row = sdk[tid]
        j_row = jsonl[tid]
        t_row = files[tid]
        s_metrics = s_row["metrics"]
        j_metrics = j_row["metrics"]
        t_metrics = t_row["metrics"]
        model = f_row["model"]
        print(f"\n  Trial {tid} ({model}):")

        # Status
        check(f"  status consistent",
              f_row["status"] == s_row["status"] == j_row["status"] == t_row["status"],
              f"FE={f_row['status']}, SDK={s_row['status']}, JSONL={j_row['status']}, File={t_row['status']}")

        # Model
        check(f"  model consistent",
              f_row["model"] == s_row["config"]["model"] == j_row["config"]["model"] == t_row["config"]["model"],
              f"FE={f_row['model']}, SDK={s_row['config']['model']}")

        # Full config between SDK/JSONL/trial file
        check(
            "  full config consistent (SDK/JSONL/File)",
            s_row["config"] == j_row["config"] == t_row["config"],
            f"SDK={s_row['config']}, JSONL={j_row['config']}, File={t_row['config']}",
        )

        # tool_accuracy
        sdk_ta = s_metrics.get("tool_accuracy")
        jsonl_ta = j_metrics.get("tool_accuracy")
        file_ta = t_metrics.get("tool_accuracy")
        fe_ta = f_row["tool_accuracy"]
        check(
            "  tool_accuracy present in SDK/JSONL/File",
            sdk_ta is not None and jsonl_ta is not None and file_ta is not None,
            f"SDK={sdk_ta}, JSONL={jsonl_ta}, File={file_ta}",
        )
        if sdk_ta is not None and jsonl_ta is not None and file_ta is not None:
            check(
                "  tool_accuracy consistent",
                all_close(
                    {
                        "FE": fe_ta,
                        "SDK": float(sdk_ta),
                        "JSONL": float(jsonl_ta),
                        "File": float(file_ta),
                    },
                    abs_tol=TOLERANCES["accuracy_like"],
                ),
                f"FE={fe_ta}, SDK={sdk_ta}, JSONL={jsonl_ta}, File={file_ta}",
            )

        # param_accuracy
        sdk_pa = s_metrics.get("param_accuracy")
        jsonl_pa = j_metrics.get("param_accuracy")
        file_pa = t_metrics.get("param_accuracy")
        fe_pa = f_row["param_accuracy"]
        check(
            "  param_accuracy present in SDK/JSONL/File",
            sdk_pa is not None and jsonl_pa is not None and file_pa is not None,
            f"SDK={sdk_pa}, JSONL={jsonl_pa}, File={file_pa}",
        )
        if sdk_pa is not None and jsonl_pa is not None and file_pa is not None:
            check(
                "  param_accuracy consistent",
                all_close(
                    {
                        "FE": fe_pa,
                        "SDK": float(sdk_pa),
                        "JSONL": float(jsonl_pa),
                        "File": float(file_pa),
                    },
                    abs_tol=TOLERANCES["accuracy_like"],
                ),
                f"FE={fe_pa}, SDK={sdk_pa}, JSONL={jsonl_pa}, File={file_pa}",
            )

        # text_accuracy
        sdk_xa = s_metrics.get("text_accuracy")
        jsonl_xa = j_metrics.get("text_accuracy")
        file_xa = t_metrics.get("text_accuracy")
        fe_xa = f_row["text_accuracy"]
        check(
            "  text_accuracy present in SDK/JSONL/File",
            sdk_xa is not None and jsonl_xa is not None and file_xa is not None,
            f"SDK={sdk_xa}, JSONL={jsonl_xa}, File={file_xa}",
        )
        if sdk_xa is not None and jsonl_xa is not None and file_xa is not None:
            check(
                "  text_accuracy consistent",
                all_close(
                    {
                        "FE": fe_xa,
                        "SDK": float(sdk_xa),
                        "JSONL": float(jsonl_xa),
                        "File": float(file_xa),
                    },
                    abs_tol=TOLERANCES["accuracy_like"],
                ),
                f"FE={fe_xa}, SDK={sdk_xa}, JSONL={jsonl_xa}, File={file_xa}",
            )

        # accuracy (all sources)
        sdk_acc = s_metrics.get("accuracy")
        jsonl_acc = j_metrics.get("accuracy")
        file_acc = t_metrics.get("accuracy")
        fe_acc = parse_pct(f_row["accuracy_pct"])
        check(
            "  accuracy present in SDK/JSONL/File",
            sdk_acc is not None and jsonl_acc is not None and file_acc is not None,
            f"SDK={sdk_acc}, JSONL={jsonl_acc}, File={file_acc}",
        )
        if sdk_acc is not None and jsonl_acc is not None and file_acc is not None:
            check(
                "  accuracy consistent",
                all_close(
                    {
                        "FE": fe_acc,
                        "SDK": float(sdk_acc),
                        "JSONL": float(jsonl_acc),
                        "File": float(file_acc),
                    },
                    abs_tol=TOLERANCES["accuracy_like"],
                ),
                f"FE={fe_acc:.4f} (from {f_row['accuracy_pct']}), SDK={sdk_acc}, JSONL={jsonl_acc}, File={file_acc}",
            )

        # score (all sources)
        sdk_score = s_metrics.get("score")
        jsonl_score = j_metrics.get("score")
        file_score = t_metrics.get("score")
        fe_score = parse_pct(f_row["score_pct"])
        check(
            "  score present in SDK/JSONL/File",
            sdk_score is not None and jsonl_score is not None and file_score is not None,
            f"SDK={sdk_score}, JSONL={jsonl_score}, File={file_score}",
        )
        if sdk_score is not None and jsonl_score is not None and file_score is not None:
            check(
                "  score consistent",
                all_close(
                    {
                        "FE": fe_score,
                        "SDK": float(sdk_score),
                        "JSONL": float(jsonl_score),
                        "File": float(file_score),
                    },
                    abs_tol=TOLERANCES["accuracy_like"],
                ),
                f"FE={fe_score:.4f} (from {f_row['score_pct']}), SDK={sdk_score}, JSONL={jsonl_score}, File={file_score}",
            )

        # latency / response_time
        sdk_lat = s_metrics.get("latency")
        jsonl_lat = j_metrics.get("latency")
        file_lat = t_metrics.get("latency")
        sdk_rt = s_metrics.get("response_time_ms")
        jsonl_rt = j_metrics.get("response_time_ms")
        file_rt = t_metrics.get("response_time_ms")
        fe_lat = f_row["latency"]
        fe_rt = float(f_row["response_time_str"].lower().replace("ms", "").strip())
        check(
            "  latency present in SDK/JSONL/File",
            sdk_lat is not None and jsonl_lat is not None and file_lat is not None,
            f"SDK={sdk_lat}, JSONL={jsonl_lat}, File={file_lat}",
        )
        if sdk_lat is not None and jsonl_lat is not None and file_lat is not None:
            check(
                "  latency consistent",
                all_close(
                    {
                        "FE_latency": fe_lat,
                        "FE_response_time_ms": fe_rt,
                        "SDK_latency": float(sdk_lat),
                        "JSONL_latency": float(jsonl_lat),
                        "File_latency": float(file_lat),
                    },
                    abs_tol=TOLERANCES["latency_ms"],
                ),
                f"FE_latency={fe_lat}, FE_response_time={fe_rt}, SDK={sdk_lat}, JSONL={jsonl_lat}, File={file_lat}",
            )
        check(
            "  response_time_ms present in SDK/JSONL/File",
            sdk_rt is not None and jsonl_rt is not None and file_rt is not None,
            f"SDK={sdk_rt}, JSONL={jsonl_rt}, File={file_rt}",
        )
        if sdk_rt is not None and jsonl_rt is not None and file_rt is not None:
            check(
                "  response_time_ms consistent (SDK/JSONL/File)",
                all_close(
                    {
                        "SDK": float(sdk_rt),
                        "JSONL": float(jsonl_rt),
                        "File": float(file_rt),
                    },
                    abs_tol=TOLERANCES["latency_ms"],
                ),
                f"SDK={sdk_rt}, JSONL={jsonl_rt}, File={file_rt}",
            )

        # Cost comparison — FE displays per-example cost for this run.
        sdk_cost = s_metrics.get("cost")
        jsonl_cost = j_metrics.get("cost")
        file_cost = t_metrics.get("cost")
        sdk_total_cost = s_metrics.get("total_cost")
        jsonl_total_cost = j_metrics.get("total_cost")
        file_total_cost = t_metrics.get("total_cost")
        fe_cost = parse_dollar(f_row["cost_str"])
        fe_total_cost = parse_dollar(f_row["total_cost_str"])
        check(
            "  cost present in SDK/JSONL/File",
            sdk_cost is not None and jsonl_cost is not None and file_cost is not None,
            f"SDK={sdk_cost}, JSONL={jsonl_cost}, File={file_cost}",
        )
        if sdk_cost is not None and jsonl_cost is not None and file_cost is not None:
            check(
                "  cost consistent (SDK/JSONL/File)",
                all_close(
                    {
                        "SDK": float(sdk_cost),
                        "JSONL": float(jsonl_cost),
                        "File": float(file_cost),
                    },
                    abs_tol=TOLERANCES["cost_total"],
                ),
                f"SDK={sdk_cost}, JSONL={jsonl_cost}, File={file_cost}",
            )
        check(
            "  total_cost present in SDK/JSONL/File",
            sdk_total_cost is not None
            and jsonl_total_cost is not None
            and file_total_cost is not None,
            f"SDK={sdk_total_cost}, JSONL={jsonl_total_cost}, File={file_total_cost}",
        )
        if (
            sdk_total_cost is not None
            and jsonl_total_cost is not None
            and file_total_cost is not None
        ):
            check(
                "  total_cost consistent (SDK/JSONL/File)",
                all_close(
                    {
                        "SDK": float(sdk_total_cost),
                        "JSONL": float(jsonl_total_cost),
                        "File": float(file_total_cost),
                    },
                    abs_tol=TOLERANCES["cost_total"],
                ),
                f"SDK={sdk_total_cost}, JSONL={jsonl_total_cost}, File={file_total_cost}",
            )
        if sdk_cost is not None and sdk_total_cost is not None:
            check(
                "  SDK cost == SDK total_cost",
                approx_eq(
                    float(sdk_cost),
                    float(sdk_total_cost),
                    abs_tol=TOLERANCES["cost_total"],
                ),
                f"SDK_cost={sdk_cost}, SDK_total_cost={sdk_total_cost}",
            )

        trial_examples = f_row["total_examples"]
        if expected_examples is not None:
            check(
                "  total_examples matches FE-wide expected count",
                trial_examples == expected_examples,
                f"trial_examples={trial_examples}, expected={expected_examples}",
            )

        if sdk_total_cost is not None and trial_examples > 0:
            sdk_per_example_cost = float(sdk_total_cost) / float(trial_examples)
            check(
                "  cost: FE 'Cost' matches SDK per-example cost",
                approx_eq(
                    fe_cost,
                    sdk_per_example_cost,
                    abs_tol=TOLERANCES["cost_per_example"],
                ),
                f"FE_Cost={fe_cost:.6f}, SDK_total_cost/examples={sdk_per_example_cost:.6f}, SDK_total_cost={sdk_total_cost}",
            )
            check(
                "  cost: FE 'Total Cost' matches FE 'Cost' (same display value)",
                approx_eq(
                    fe_cost,
                    fe_total_cost,
                    abs_tol=TOLERANCES["cost_per_example"],
                ),
                f"FE_Cost={fe_cost}, FE_TotalCost={fe_total_cost}",
            )

        # success_rate
        sdk_sr = s_metrics.get("success_rate")
        jsonl_sr = j_metrics.get("success_rate")
        file_sr = t_metrics.get("success_rate")
        fe_sr = f_row["success_rate"]
        check(
            "  success_rate present in SDK/JSONL/File",
            sdk_sr is not None and jsonl_sr is not None and file_sr is not None,
            f"SDK={sdk_sr}, JSONL={jsonl_sr}, File={file_sr}",
        )
        if sdk_sr is not None and jsonl_sr is not None and file_sr is not None:
            check(
                "  success_rate consistent",
                all_close(
                    {
                        "FE": fe_sr,
                        "SDK": float(sdk_sr),
                        "JSONL": float(jsonl_sr),
                        "File": float(file_sr),
                    },
                    abs_tol=TOLERANCES["accuracy_like"],
                ),
                f"FE={fe_sr}, SDK={sdk_sr}, JSONL={jsonl_sr}, File={file_sr}",
            )

        # examples_attempted should match across SDK/JSONL/File and FE total_examples.
        sdk_attempted = s_metrics.get("examples_attempted")
        jsonl_attempted = j_metrics.get("examples_attempted")
        file_attempted = t_metrics.get("examples_attempted")
        check(
            "  examples_attempted present in SDK/JSONL/File",
            sdk_attempted is not None
            and jsonl_attempted is not None
            and file_attempted is not None,
            f"SDK={sdk_attempted}, JSONL={jsonl_attempted}, File={file_attempted}",
        )
        if (
            sdk_attempted is not None
            and jsonl_attempted is not None
            and file_attempted is not None
        ):
            check(
                "  examples_attempted consistent and matches FE total_examples",
                all_close(
                    {
                        "FE_total_examples": float(trial_examples),
                        "SDK_examples_attempted": float(sdk_attempted),
                        "JSONL_examples_attempted": float(jsonl_attempted),
                        "File_examples_attempted": float(file_attempted),
                    },
                    abs_tol=0.0,
                    rel_tol=0.0,
                ),
                f"FE_total_examples={trial_examples}, SDK={sdk_attempted}, JSONL={jsonl_attempted}, File={file_attempted}",
            )

    # --- Check 3: FE-only fields (Content Novelty, Content Uniqueness) ---
    print("\n--- Check 3: FE-only fields ---")
    for tid in all_trial_ids:
        if tid not in fe:
            continue
        f_row = fe[tid]
        cn = f_row["content_novelty"]
        cu = f_row["content_uniqueness"]
        check(f"  {tid}: Content Novelty present (value={cn})",
              cn is not None, f"value={cn}")
        check(f"  {tid}: Content Uniqueness present (value={cu})",
              cu is not None, f"value={cu}")

        # These don't exist in SDK results — flag as info
        if tid in sdk:
            sdk_metrics = sdk[tid]["metrics"]
            in_sdk = "content_novelty" in sdk_metrics or "content_uniqueness" in sdk_metrics
            if not in_sdk:
                print(
                    f"  [INFO] {tid}: Content Novelty/Uniqueness NOT in SDK trial metrics "
                    "(added/derived in backend analytics pipeline)"
                )

    # --- Check 4: JSONL vs per-trial file consistency ---
    print("\n--- Check 4: JSONL vs per-trial file deep comparison ---")
    for tid in all_trial_ids:
        if tid not in jsonl or tid not in files:
            continue
        j = jsonl[tid]
        t = files[tid]
        # Compare all metric keys
        j_metrics = j["metrics"]
        t_metrics = t["metrics"]
        all_keys = set(j_metrics) | set(t_metrics)
        mismatches = []
        only_in_jsonl = sorted(set(j_metrics) - set(t_metrics))
        only_in_file = sorted(set(t_metrics) - set(j_metrics))
        if only_in_jsonl:
            mismatches.append(f"keys only in JSONL={only_in_jsonl}")
        if only_in_file:
            mismatches.append(f"keys only in File={only_in_file}")

        for k in all_keys:
            if k not in j_metrics or k not in t_metrics:
                continue
            jv = j_metrics.get(k)
            tv = t_metrics.get(k)
            if isinstance(jv, (int, float)) and isinstance(tv, (int, float)):
                metric_abs_tol = TOLERANCES["cost_total"]
                if k in {"accuracy", "score", "tool_accuracy", "param_accuracy", "text_accuracy", "success_rate"}:
                    metric_abs_tol = TOLERANCES["accuracy_like"]
                elif k in {"latency", "response_time_ms"}:
                    metric_abs_tol = TOLERANCES["latency_ms"]
                elif k in {"cost", "total_cost"}:
                    metric_abs_tol = TOLERANCES["cost_total"]
                if not approx_eq(float(jv), float(tv), abs_tol=metric_abs_tol):
                    mismatches.append(f"{k}: JSONL={jv}, File={tv}")
            elif jv != tv:
                mismatches.append(f"{k}: JSONL={jv}, File={tv}")
        check(f"  {tid}: JSONL == File for all metrics",
              len(mismatches) == 0,
              "; ".join(mismatches) if mismatches else "")

    # --- Summary ---
    print("\n" + "=" * 70)
    print(f"  TOTAL CHECKS: {checks}")
    print(f"  PASSED:       {checks - len(failures)}")
    print(f"  FAILED:       {len(failures)}")
    if failures:
        print("\n  FAILURES:")
        for f in failures:
            print(f"    {f}")
    print("=" * 70)

    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
